class Agent:
    def __init__(self):
        self.Position = [0,0] # X Y Position
        self.Orientation  = [0] # Global Orientation
        self.Velocity = [0,0] # X Y Velocity
        self.ShoppingList = [] #Empty